/* include file for MacOS X startup code */
int macosxvmdstart(int argc, char **argv);
